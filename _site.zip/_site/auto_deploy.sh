#!/bin/bash
#!/bin/sh
# reset jetbrains ide evals


git pull origine main

unzip -f _site.zip /var/www/public_html/kundankb.com/*




